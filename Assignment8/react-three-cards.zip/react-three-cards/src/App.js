import React from "react";
//import Card from "./Card";
import CardList from "./CardList";
import "./App.css";

function App(){
 

  return(
    <div className="container">
      <CardList />
    </div>
  );
}
export default App;

